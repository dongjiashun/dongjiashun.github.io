Put your markdown files (Hexo/Jekyll) in this directory then start Solo, these files will be imported as posts.

把 Markdown 文件（Hexo/Jekyll）放到本目录后启动 Solo，这些 MD 文件将会被自动导入作为文章。
